/* University chrome for every Canon page. Relative paths. No network required to read. */
(function () {
  var root = document.documentElement;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function prefix() {
    var nodes = document.querySelectorAll("script[src]");
    var mark = "assets/js/university.js";
    for (var i = 0; i < nodes.length; i++) {
      var src = nodes[i].getAttribute("src") || "";
      var at = src.indexOf(mark);
      if (at !== -1) return src.slice(0, at);
    }
    return "";
  }
  var rootPrefix = prefix();
  function fromRoot(href) {
    if (!href) return "";
    if (/^(https?:|mailto:|#)/.test(href)) return href;
    return rootPrefix + String(href).replace(/^\//, "");
  }

  var LABS = [
    ["UC Lab", "https://cipher0x9.github.io/uc-lab-free-university-mesmerizing/"],
    ["AI Lab", "https://cipher0x9.github.io/ai-lab-free-university-mesmerizing/"],
    ["SIP Universe", "https://cipher0x9.github.io/sip-universe-lab-free-university-mesmerizing/"],
    ["Microsoft Voice", "https://cipher0x9.github.io/microsoft-voice-cc-lab-free-university-mesmerizing/"],
    ["Amazon Connect", "https://cipher0x9.github.io/amazon-connect-lab-free-university-mesmerizing/"],
    ["Genesys Cloud", "https://cipher0x9.github.io/genesys-cloud-lab-free-university-mesmerizing/"],
    ["Five9", "https://cipher0x9.github.io/five9-lab-free-university-mesmerizing/"],
    ["NICE CXone", "https://cipher0x9.github.io/nice-cxone-lab-free-university-mesmerizing/"]
  ];
  var CONTACT = "https://cyphermonkeylabs.com";
  var REPO = "https://github.com/cipher0x9/webex-lab-free-university-mesmerizing";

  var stage = document.querySelector(".v4-stage");
  if (stage && !document.querySelector(".lab-links")) {
    var bar = document.createElement("nav");
    bar.className = "lab-links";
    bar.setAttribute("aria-label", "CypherMonkey");
    bar.innerHTML =
      '<a href="https://cyphermonkeylabs.com">Labs home</a>' +
      '<a href="https://linktr.ee/cyphermonkey">Linktree</a>' +
      '<a href="' + REPO + '">Rate, comment, help</a>' +
      '<a href="https://dev.to/cyphermonkey">dev.to</a>' +
      '<a href="https://huggingface.co/Cypher0x9">Hugging Face</a>' +
      '<a href="https://x.com/Cypher0x9">X</a>' +
      '<button type="button" data-offline-save>Save for offline</button>' +
      '<a href="' + fromRoot("downloads/webex-university-offline.zip") + '">Offline bundle</a>';
    stage.insertBefore(bar, stage.firstChild);
  }

  function footerHtml() {
    var labs = LABS.map(function (lab) {
      return '<a href="' + lab[1] + '">' + lab[0] + "<small>Next lab</small></a>";
    }).join("");
    return (
      '<p class="lab-sign">CypherMonkey · Webex Lab Free University</p>' +
      '<p>Independent educational project. Not affiliated with or endorsed by Cisco or any other vendor. Trademarks belong to their owners. MIT code. CC BY-NC-SA content.</p>' +
      '<p class="lab-actions">' +
      '<a href="' + CONTACT + '">Report a concern / takedown</a>' +
      '<a href="' + CONTACT + '">Work with us</a>' +
      '<a href="' + fromRoot("downloads.html") + '">Cheat Codes</a>' +
      '<a href="' + fromRoot("play.html") + '">Play Lab</a>' +
      "</p>" +
      '<nav class="next-labs" aria-label="Other labs">' + labs + "</nav>"
    );
  }
  var foot = document.querySelector(".site-footer");
  if (foot) {
    foot.classList.add("lab-footer");
    foot.innerHTML = footerHtml();
  } else {
    var main = document.querySelector("main") || document.body;
    var extra = document.createElement("footer");
    extra.className = "site-footer lab-footer wrap";
    extra.innerHTML = footerHtml();
    main.appendChild(extra);
  }

  var FACES = [
    { name: "wave", line: "Start in Control Hub, then a dial plan.", mouth: "M28 58 Q40 68 52 58" },
    { name: "think", line: "5062 is the certificate trunk. 8934 is registration.", mouth: "M30 62 H50" },
    { name: "grin", line: "933 tests emergency. It does not call public safety.", mouth: "M26 56 Q40 72 54 56" },
    { name: "focus", line: "Recording turns Calling end-to-end encryption off.", mouth: "M32 60 Q40 56 48 60" }
  ];
  function faceSvg(face) {
    return (
      '<svg viewBox="0 0 80 96" aria-hidden="true">' +
      '<ellipse cx="40" cy="86" rx="18" ry="6" fill="#0b1020" opacity=".35"/>' +
      '<path d="M22 70c-8 2-12 10-8 14 6 2 16-2 18-8" fill="#a16207"/>' +
      '<path d="M58 70c8 2 12 10 8 14-6 2-16-2-18-8" fill="#a16207"/>' +
      '<circle cx="40" cy="42" r="26" fill="#fbbf24"/>' +
      '<circle cx="18" cy="46" r="8" fill="#f59e0b"/>' +
      '<circle cx="62" cy="46" r="8" fill="#f59e0b"/>' +
      '<circle cx="30" cy="40" r="4" fill="#1c1917"/>' +
      '<circle cx="50" cy="40" r="4" fill="#1c1917"/>' +
      '<circle cx="31" cy="39" r="1.2" fill="#fff"/>' +
      '<path d="' + face.mouth + '" fill="none" stroke="#1c1917" stroke-width="2.4" stroke-linecap="round"/>' +
      '<path d="M24 28c4-10 28-10 32 0" fill="none" stroke="#92400e" stroke-width="3" stroke-linecap="round"/>' +
      "</svg>"
    );
  }
  var faceAt = new Date().getHours() % FACES.length;
  var monkey = document.createElement("button");
  monkey.type = "button";
  monkey.className = "monkey" + (reduce ? "" : " is-live");
  monkey.setAttribute("aria-label", "CypherMonkey. " + FACES[faceAt].line);
  monkey.innerHTML = faceSvg(FACES[faceAt]);
  var note = document.createElement("div");
  note.className = "monkey-note";
  note.hidden = true;
  note.textContent = FACES[faceAt].line;
  document.body.appendChild(monkey);
  document.body.appendChild(note);
  monkey.addEventListener("click", function () {
    note.hidden = !note.hidden;
    note.textContent = FACES[faceAt].line;
  });
  if (!reduce) {
    window.setInterval(function () {
      faceAt = (faceAt + 1) % FACES.length;
      monkey.innerHTML = faceSvg(FACES[faceAt]);
      monkey.setAttribute("aria-label", "CypherMonkey. " + FACES[faceAt].line);
      if (!note.hidden) note.textContent = FACES[faceAt].line;
    }, 8000);
  }

  function badges() {
    try { return JSON.parse(localStorage.getItem("canon-badges") || "{}"); }
    catch (err) { return {}; }
  }
  function award(id) {
    var bag = badges();
    if (bag[id]) return false;
    bag[id] = new Date().toISOString();
    try { localStorage.setItem("canon-badges", JSON.stringify(bag)); } catch (err) { /* storage off */ }
    document.dispatchEvent(new CustomEvent("canon-badge", { detail: id }));
    return true;
  }
  window.CANON_UNIVERSITY = { fromRoot: fromRoot, award: award, badges: badges, contact: CONTACT, repo: REPO };

  try {
    var progress = JSON.parse(localStorage.getItem("canon-progress") || "{}");
    var opened = progress && progress.rooms ? Object.keys(progress.rooms).length : 0;
    if (opened >= 1) award("first-room");
    if (opened >= 10) award("ten-rooms");
    if (opened >= 63) award("all-rooms");
  } catch (err) { /* ignore */ }

  var konami = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight", "b", "a"];
  var konamiAt = 0;
  document.addEventListener("keydown", function (event) {
    var key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
    if (key === konami[konamiAt]) {
      konamiAt += 1;
      if (konamiAt === konami.length) {
        konamiAt = 0;
        award("konami");
        var layer = document.createElement("div");
        layer.className = "egg-layer";
        layer.innerHTML = '<div class="egg-card" role="dialog" aria-label="Banana trunk"><p>Banana trunk unlocked.</p><p>CypherMonkey saved a badge in this browser. The trunk is still not a Cisco feature.</p><button type="button" class="ghost">Close</button></div>';
        document.body.appendChild(layer);
        layer.querySelector("button").addEventListener("click", function () { layer.remove(); });
        layer.addEventListener("click", function (ev) { if (ev.target === layer) layer.remove(); });
      }
    } else {
      konamiAt = key === konami[0] ? 1 : 0;
    }
  });

  function cacheUrls(urls) {
    if (!("caches" in window)) return Promise.reject(new Error("Cache Storage is unavailable"));
    return caches.open("webex-university-v1").then(function (cache) {
      return Promise.all(urls.map(function (url) {
        return fetch(url).then(function (response) {
          if (response && response.ok) return cache.put(url, response);
          return null;
        }).catch(function () { return null; });
      }));
    });
  }
  document.querySelectorAll("[data-offline-save]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      btn.disabled = true;
      var label = btn.textContent;
      btn.textContent = "Saving…";
      var manifest = fromRoot("downloads/cache-manifest.json");
      fetch(manifest).then(function (response) { return response.json(); }).then(function (list) {
        var urls = (list || []).map(function (item) { return fromRoot(item); });
        return cacheUrls(urls);
      }).then(function () {
        award("offline");
        btn.textContent = "Saved in this browser";
      }).catch(function () {
        btn.disabled = false;
        btn.textContent = label;
      });
    });
  });

  if ("serviceWorker" in navigator && location.protocol.indexOf("http") === 0) {
    navigator.serviceWorker.register(fromRoot("sw.js")).catch(function () { /* pages still work */ });
  }

  document.dispatchEvent(new CustomEvent("university-ready"));
})();
