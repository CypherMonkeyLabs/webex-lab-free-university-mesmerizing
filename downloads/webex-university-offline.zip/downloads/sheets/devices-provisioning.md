# Devices and provisioning

Devices and provisioning One page pulled from the Canon rooms named in the source column. Open the room before you quote a number in a design. This is not a copy of a Cisco document. Check What the room says Source What two claims does Control Hub offer? MAC address, or an activation code. A blank MAC generates the code. [cite:1] T2-R04-devices-provisioning.html How long is the code? 16 digits. [cite:2] T2-R04-devices-provisioning.html How long does an MPP code last? 30 days. A Room device code lasts 7 days. [cite:2] T2-R04-devices-provisioning.html Which firmware can type the code? MPP firmware 11.3.1 SR2 or later. [cite:1] T2-R04-devices-provisioning.html How many devices on a professional workspace? Up to five of the phone types the article names. [cite:3] T2-R04-devices-provisioning.html What is the default calling service for a Room or Desk workspace? Call on Webex, which is 1:1 and non-PSTN. [cite:3] T2-R04-devices-provisioning.html Which CSV device types cover RoomOS? WEBEX or WEBEX_CALLING. IP is for MPP, ATA, and DECT. [cite:1] T2-R04-devices-provisioning.html Back to the lab · Cheat Codes

## Sources and go deeper

Checked links were opened this month. A confirm row has no address because that page was not opened.

- Wikipedia: [Webex (Wikipedia)](https://en.wikipedia.org/wiki/Webex) — last checked 2026-10
- Vendor doc: [Webex Help Center](https://help.webex.com/) — last checked 2026-10
- DevDocs: [Webex developer documentation](https://developer.webex.com/) — last checked 2026-10
- DevDocs: [Webex developer getting started](https://developer.webex.com/docs/getting-started) — last checked 2026-10
- Community: [Webex community](https://help.webex.com/community) — last checked 2026-10
- SRND: [Cisco Collaboration design zone](https://www.cisco.com/c/en/us/solutions/enterprise/design-zone-collaboration/index.html) — last checked 2026-10
- RFC: [RFC 3261 SIP: Session Initiation Protocol](https://www.rfc-editor.org/rfc/rfc3261) — last checked 2026-10
- Port table: [IANA service name and port number registry](https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml) — last checked 2026-10
- Port table: [Port reference for Webex Calling](https://help.webex.com/article/b2exve) — last checked 2026-10
- RFC: [RFC 3263 Locating SIP Servers](https://www.rfc-editor.org/rfc/rfc3263) — last checked 2026-10
- RFC: [RFC 3264 An Offer/Answer Model with SDP](https://www.rfc-editor.org/rfc/rfc3264) — last checked 2026-10
- Wikipedia: [Session Initiation Protocol (Wikipedia)](https://en.wikipedia.org/wiki/Session_Initiation_Protocol) — last checked 2026-10
- RFC: [RFC 3550 RTP](https://www.rfc-editor.org/rfc/rfc3550) — last checked 2026-10
- RFC: [RFC 3711 SRTP](https://www.rfc-editor.org/rfc/rfc3711) — last checked 2026-10
- RFC: [RFC 4566 SDP](https://www.rfc-editor.org/rfc/rfc4566) — last checked 2026-10
- RFC: [RFC 4733 RTP payload for DTMF](https://www.rfc-editor.org/rfc/rfc4733) — last checked 2026-10
- Wikipedia: [Real-time Transport Protocol (Wikipedia)](https://en.wikipedia.org/wiki/Real-time_Transport_Protocol) — last checked 2026-10
- Release notes: [What's new in Webex Calling](https://help.webex.com/article/278bz2) — last checked 2026-10
- Vendor doc: [help.webex.com article n9r1aac](https://help.webex.com/article/n9r1aac) — last checked 2026-10
- Vendor doc: [help.webex.com article ndb7w0db](https://help.webex.com/article/ndb7w0db) — last checked 2026-10
- Vendor doc: [help.webex.com article 1mqb9cb](https://help.webex.com/article/1mqb9cb) — last checked 2026-10

---

Independent, free, learning-only student project. Not affiliated with or endorsed by any vendor. Trademarks belong to their owners. Concerns: https://cyphermonkeylabs.com/#contact

CypherMonkey Labs

© 2026 CypherMonkeyLabs

https://cyphermonkeylabs.com
https://github.com/CypherMonkeyLabs
https://linktr.ee/cyphermonkey
